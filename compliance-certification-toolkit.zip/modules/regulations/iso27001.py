class ISO27001Rule:
    def __init__(self):
        self.scroll = None  # placeholder
