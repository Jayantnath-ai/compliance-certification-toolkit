class HIPAARule:
    def __init__(self):
        self.scroll = "scrolls/hipaa/sample_scroll.yaml"
