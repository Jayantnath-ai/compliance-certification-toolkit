class GDPRRule:
    def __init__(self):
        # Mock scroll path
        self.scroll = "scrolls/gdpr/sample_scroll.yaml"
