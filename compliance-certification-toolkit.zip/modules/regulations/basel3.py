class Basel3Rule:
    def __init__(self):
        self.scroll = None  # placeholder
