class HealthIndustry:
    def __init__(self):
        self.forks = [
            {"condition": "context.get('phi_protected')", "description": "PHI protected"}
        ]
